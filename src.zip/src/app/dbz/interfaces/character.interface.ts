export interface Personaje {
  id?: number; // Hacer 'id' opcional
  nombre: string;
  fuerza: number;
}